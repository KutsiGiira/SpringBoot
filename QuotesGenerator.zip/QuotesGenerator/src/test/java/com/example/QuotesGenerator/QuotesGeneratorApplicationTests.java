package com.example.QuotesGenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuotesGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
